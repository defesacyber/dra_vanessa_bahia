import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PhilosophicalLabel } from "../types";

const apiKey = process.env.API_KEY;

// Ensure API key exists
if (!apiKey) {
  console.error("API_KEY is missing via process.env.API_KEY");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "" });

const NUTRITION_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    servingSize: { type: Type.STRING, description: "Context of the input (e.g., '1 Anxiety Attack', '1 Career Choice')" },
    calories: { type: Type.INTEGER, description: "The 'mental weight' or heaviness of the thought (0-2000)" },
    virtues: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          amount: { type: Type.STRING, description: "Percentage or descriptor (e.g., 'High')" },
          description: { type: Type.STRING },
        }
      }
    },
    vices: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Fallacies, biases, or negative emotions" },
          amount: { type: Type.STRING },
          description: { type: Type.STRING },
        }
      }
    },
    mainIngredients: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Philosophical schools or concepts present (e.g., 'Nihilism', 'Ethics')"
    },
    vitamins: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Positive philosophical nutrients (e.g., 'Vitamin Courage')" },
          amount: { type: Type.STRING },
          description: { type: Type.STRING },
        }
      }
    },
    analysis: { type: Type.STRING, description: "A deep, insightful philosophical analysis of the thought." },
    prescription: { type: Type.STRING, description: "Actionable philosophical advice or 'dietary' restrictions." }
  },
  required: ["servingSize", "calories", "virtues", "vices", "mainIngredients", "vitamins", "analysis", "prescription"]
};

export const analyzeThought = async (thought: string): Promise<PhilosophicalLabel> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: thought,
      config: {
        systemInstruction: `
          Você é o Nutricionista Chefe do "Laboratório de Inteligência Filosófica".
          Seu objetivo é analisar os pensamentos, medos e dilemas do usuário como se fossem alimentos e gerar uma "Tabela Nutricional Filosófica".
          
          Metáfora:
          - Calorias: Peso mental do pensamento.
          - Vícios (Gorduras/Sódio): Falácias lógicas, apegos, medos irracionais.
          - Virtudes (Proteínas): Lógica, coragem, temperança, justiça.
          - Vitaminas: Insights específicos (e.g., Vitamina S = Estoicismo).
          
          Seja clínico, mas profundamente perspicaz. Use terminologia filosófica correta (Kant, Nietzsche, Sêneca, etc.) misturada com a metáfora nutricional.
          A resposta deve ser estritamente JSON.
        `,
        responseMimeType: "application/json",
        responseSchema: NUTRITION_SCHEMA,
        temperature: 0.7,
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as PhilosophicalLabel;
    }
    throw new Error("No text returned from Gemini");
  } catch (error) {
    console.error("Error analyzing thought:", error);
    throw error;
  }
};

export const chatWithPhilosopher = async (history: { role: string, parts: { text: string }[] }[], newMessage: string, context: PhilosophicalLabel) => {
  // We create a chat session that knows the context of the previous analysis
  const chat = ai.chats.create({
    model: "gemini-2.5-flash",
    config: {
      systemInstruction: `
        Você é um mentor filosófico discutindo a análise nutricional mental do usuário.
        
        Contexto da Análise Anterior:
        Peso Mental: ${context.calories}
        Diagnóstico: ${context.analysis}
        Prescrição: ${context.prescription}
        
        Mantenha o diálogo socrático. Faça perguntas. Ajude o usuário a digerir o insight.
      `
    },
    history: history
  });

  const result = await chat.sendMessage({ message: newMessage });
  return result.text;
};
