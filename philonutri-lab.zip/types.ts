export interface MacroNutrient {
  name: string;
  amount: string; // e.g. "High", "20%", "Critical"
  description: string;
}

export interface PhilosophicalLabel {
  servingSize: string; // e.g., "1 Dilemma", "1 Worry"
  calories: number; // Metaphorical "Mental Weight"
  virtues: MacroNutrient[];
  vices: MacroNutrient[]; // e.g. Fallacies, Cognitive Distortions
  mainIngredients: string[]; // e.g., "Stoicism", "Existential Dread"
  vitamins: MacroNutrient[]; // e.g., "Vitamin Logic", "Vitamin Empathy"
  analysis: string; // The main text summary
  prescription: string; // "Dietary" advice (books, practices)
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export enum AppState {
  INPUT,
  ANALYZING,
  RESULTS,
}
