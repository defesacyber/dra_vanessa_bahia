import React, { useState } from 'react';
import { analyzeThought } from './services/geminiService';
import { PhilosophicalLabel, AppState } from './types';
import { NutritionCard } from './components/NutritionCard';
import { ChatInterface } from './components/ChatInterface';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(AppState.INPUT);
  const [input, setInput] = useState('');
  const [result, setResult] = useState<PhilosophicalLabel | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!input.trim()) return;
    
    setState(AppState.ANALYZING);
    setError(null);
    
    try {
      const analysis = await analyzeThought(input);
      setResult(analysis);
      setState(AppState.RESULTS);
    } catch (err) {
      console.error(err);
      setError("Não foi possível processar este pensamento no laboratório. Verifique sua conexão ou tente simplificar a ideia.");
      setState(AppState.INPUT);
    }
  };

  const handleReset = () => {
    setInput('');
    setResult(null);
    setState(AppState.INPUT);
  };

  return (
    <div className="min-h-screen bg-[#fcfbf9] text-stone-900 selection:bg-amber-200 selection:text-stone-900">
      
      {/* Header */}
      <header className="border-b border-stone-200 bg-white py-6 sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-stone-900 text-white flex items-center justify-center rounded-full font-serif font-bold text-xl">
              Φ
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight serif">PhiloNutri Lab</h1>
              <p className="text-xs text-stone-500 uppercase tracking-widest">Inteligência Nutricional</p>
            </div>
          </div>
          {state === AppState.RESULTS && (
            <button 
              onClick={handleReset}
              className="text-sm underline decoration-stone-400 underline-offset-4 hover:text-amber-600 transition-colors animate-enter"
            >
              Nova Análise
            </button>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        
        {/* INPUT STATE */}
        {state === AppState.INPUT && (
          <div className="max-w-2xl mx-auto space-y-8">
            <div className="text-center space-y-4 animate-enter">
              <h2 className="serif text-5xl md:text-7xl text-stone-900 leading-tight tracking-tighter">
                <span className="font-light italic text-stone-600">O que você está</span> <br/> 
                <span className="font-black text-amber-700 decoration-amber-200 decoration-4 underline underline-offset-8">digerindo</span> 
                <span className="font-light italic text-stone-600"> hoje?</span>
              </h2>
              <p className="text-stone-600 text-lg font-light max-w-lg mx-auto pt-4">
                Insira um dilema, uma preocupação ou um pensamento recorrente. 
                Nosso laboratório irá decompor os ingredientes filosóficos.
              </p>
            </div>

            <div className="bg-white p-2 rounded-xl shadow-lg border border-stone-200 focus-within:ring-2 focus-within:ring-amber-500/50 transition-all duration-300 animate-enter delay-100">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ex: Estou ansioso com o futuro da minha carreira e sinto que minhas escolhas até agora foram inúteis..."
                className="w-full h-40 p-4 resize-none outline-none text-lg text-stone-700 placeholder:text-stone-300 bg-transparent rounded-lg"
              />
              <div className="flex justify-between items-center px-4 pb-2 pt-2 border-t border-stone-100">
                <span className="text-xs text-stone-400 font-mono">
                  {input.length} caracteres
                </span>
                <button
                  onClick={handleAnalyze}
                  disabled={!input.trim()}
                  className="bg-stone-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-95 transition-all"
                >
                  Analisar Nutrientes
                </button>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 text-red-700 border border-red-200 rounded-lg text-sm text-center animate-enter">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12 opacity-60 animate-enter delay-200">
              <div className="text-center space-y-2">
                <div className="text-2xl">🏛️</div>
                <h3 className="font-bold text-sm">Estoicismo</h3>
                <p className="text-xs text-stone-500">Detectar controle vs. aceitação</p>
              </div>
              <div className="text-center space-y-2">
                <div className="text-2xl">🌌</div>
                <h3 className="font-bold text-sm">Existencialismo</h3>
                <p className="text-xs text-stone-500">Analisar liberdade e angústia</p>
              </div>
              <div className="text-center space-y-2">
                <div className="text-2xl">⚖️</div>
                <h3 className="font-bold text-sm">Ética</h3>
                <p className="text-xs text-stone-500">Avaliar virtude e dever</p>
              </div>
            </div>
          </div>
        )}

        {/* ANALYZING STATE */}
        {state === AppState.ANALYZING && (
          <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-6 animate-enter">
            <div className="relative w-24 h-24">
              <div className="absolute inset-0 border-4 border-stone-200 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-amber-500 rounded-full border-t-transparent animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center font-serif text-2xl font-bold text-stone-800">
                Φ
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-medium text-stone-800">Processando Amostra Mental...</h3>
              <p className="text-sm text-stone-500 animate-pulse">Separando falácias lógicas de virtudes essenciais.</p>
            </div>
          </div>
        )}

        {/* RESULTS STATE */}
        {state === AppState.RESULTS && result && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Left Column: The Label */}
            <div className="lg:col-span-5 flex flex-col items-center animate-slide-up">
              <div className="sticky top-28">
                <NutritionCard data={result} />
                <div className="mt-6 text-center">
                   <p className="text-xs text-stone-400 uppercase tracking-widest mb-2">Selo de Qualidade</p>
                   <div className="inline-block border border-stone-300 px-3 py-1 rounded-full text-xs font-mono text-stone-500">
                     Verificado pelo Gemini 2.5
                   </div>
                </div>
              </div>
            </div>

            {/* Right Column: Analysis & Chat */}
            <div className="lg:col-span-7 space-y-8">
              
              <div className="bg-white p-8 rounded-xl shadow-sm border border-stone-200 animate-slide-up delay-100">
                <h2 className="serif text-2xl font-bold text-stone-800 mb-4">Laudo Laboratorial</h2>
                <div className="prose prose-stone leading-relaxed text-stone-600">
                  <p className="whitespace-pre-line">{result.analysis}</p>
                </div>
              </div>

              <div className="bg-amber-50 p-6 rounded-xl border border-amber-200/60 relative overflow-hidden animate-slide-up delay-200">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-amber-900 text-6xl font-serif">℞</div>
                <h3 className="serif text-lg font-bold text-amber-900 mb-2">Prescrição Filosófica</h3>
                <p className="text-amber-800/80 text-sm leading-relaxed">
                  {result.prescription}
                </p>
              </div>

              <div className="animate-slide-up delay-300">
                <ChatInterface analysisContext={result} />
              </div>

            </div>
          </div>
        )}
      </main>

      <footer className="py-8 text-center text-stone-400 text-xs border-t border-stone-200 mt-12">
        <p>© {new Date().getFullYear()} PhiloNutri Lab. Uma experiência de Inteligência Artificial.</p>
        <p className="mt-1">Não substitui acompanhamento psicológico profissional.</p>
      </footer>
    </div>
  );
};

export default App;